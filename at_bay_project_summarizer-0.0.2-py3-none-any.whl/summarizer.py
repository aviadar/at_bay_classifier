from transformers import pipeline


class Summarizer:
    def __init__(self, gpu=0):
        if gpu == 0:
            self.summarizer = pipeline("summarization",
                                       device=0,
                                       model="facebook/bart-large-cnn")
        else:
            self.summarizer = pipeline("summarization",
                                       model="facebook/bart-large-cnn")

    def summarize(self, in_text, max_length=130, min_length=30, do_sample=False):
        return self.summarizer(in_text, max_length=max_length, min_length=min_length, do_sample=do_sample)[0]['summary_text']

